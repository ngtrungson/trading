""" Distributor init file

Distributors: you can add custom code here to support particular distributions
of numpy.

For example, this is a good place to put any checks for hardware requirements.

The numpy standard source distribution will not put code in this file, so you
can safely replace this file with your own version.
"""


def init_numpy_mkl():
    """Initialize numpy+MKL."""
    try:
        import ctypes
        import os
        import sys

        # Disable Intel Fortran default console event handler.
        # Disable OpenBLAS affinity setting of the main thread that limits
        #   Python threads or processes to one core.
        for env in (
            'FOR_DISABLE_CONSOLE_CTRL_HANDLER',
            'OPENBLAS_MAIN_FREE',
            'GOTOBLAS_MAIN_FREE',
        ):
            if env not in os.environ:
                os.environ[env] = '1'

        # Add the paths of the Intel runtime DLLs to the DLL search path
        path = os.path.join(sys.prefix, 'Library', 'bin')
        path2 = os.path.join(
            sys.prefix, 'bin' + ('' if '64 bit' in sys.version else '32')
        )
        for pth in (path, path2):
            try:
                os.add_dll_directory(pth)
            except Exception:
                pass
        environ_path = os.environ.get('PATH', '')
        if path not in environ_path:
            os.environ['PATH'] = os.pathsep.join((path, path2, environ_path))

        # Load Intel C, Fortran, and OMP runtime DLLs into the process
        for dll in ('libmmd.dll', 'libifcoremd.dll', 'libiomp5md.dll'):
            try:
                ctypes.CDLL(os.path.join(path, dll))
            except Exception:
                try:
                    ctypes.CDLL(os.path.join(path2, 'libiomp5md.dll'))
                except Exception:
                    pass

    except Exception:
        pass


init_numpy_mkl()

NUMPY_MKL = True
